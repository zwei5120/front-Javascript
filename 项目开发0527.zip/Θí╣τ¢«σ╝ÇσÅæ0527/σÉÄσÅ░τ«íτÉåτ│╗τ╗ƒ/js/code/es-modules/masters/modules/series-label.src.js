/**
 * @license Highcharts JS v9.1.0 (2021-05-03)
 * @module highcharts/modules/series-label
 * @requires highcharts
 *
 * (c) 2009-2021 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Extensions/SeriesLabel.js';
