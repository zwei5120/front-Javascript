/**
 * @license Highcharts JS v9.1.0 (2021-05-03)
 * @module highcharts/modules/broken-axis
 * @requires highcharts
 *
 * (c) 2009-2021 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Core/Axis/BrokenAxis.js';
